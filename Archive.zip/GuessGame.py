import random


def generate_number(difficulty):
    secret_value = random.randint(1, difficulty)
    return secret_value


def get_guess_from_user(difficulty):
    guess_value = input(f"please choose a number between 1 to {difficulty}: ")
    while guess_value.isdigit() is False or int(guess_value) < 1 or int(guess_value) > difficulty:
        guess_value = input(f"please choose a number between 1 to {difficulty}: ")
    return int(guess_value)


def compare_results(secret_value, guess_value):
    if secret_value == guess_value:
        return True
    return False


def play(difficulty):
    guess_value = get_guess_from_user(difficulty=difficulty)
    secret_value = generate_number(difficulty=difficulty)
    return compare_results(secret_value, guess_value)


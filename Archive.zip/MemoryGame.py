import random
import time
from os import system, name


def generate_sequence(difficulty):
    gen_lis =[]
    while len(gen_lis) < difficulty:
        gen_lis.append(random.randint(1, 101))
    return gen_lis

def find_place_in_list(lis):
    len_lis = len(lis)
    if len_lis == 0:
        place_in_list = "1st"
    elif len_lis == 1:
        place_in_list = "2nd"
    elif len_lis == 2:
        place_in_list = "3rd"
    elif len_lis == 3:
        place_in_list = "4th"
    elif len_lis == 4:
        place_in_list = "5th"
    return place_in_list


def get_list_from_user(difficulty):
    user_lis = []
    while len(user_lis) < difficulty:
        place_in_list = find_place_in_list(lis=user_lis)
        guess_value = input(f"what was the {place_in_list} place in the list (between 1 to 101): ")
        while guess_value.isdigit() is False or int(guess_value) < 1 or int(guess_value) > 101:
            guess_value = input(f"what was the {place_in_list} place in the list (between 1 to 101): ")
        user_lis.append(int(guess_value))
    return user_lis


def is_list_equal(gen_lis, user_lis):
    if gen_lis == user_lis:
        return True
    return False


def clear():

    # for windows
    if name == 'nt':
        _ = system('cls')

    # for mac and linux(here, os.name is 'posix')
    else:
        _ = system('clear')


def play(difficulty):
    secret_sequence = generate_sequence(difficulty=difficulty)
    enter_game = input("welcome to the Memory Game, please try to remember the sequence of numbers,"
                       " they will be displayed only for 0.7 sec, press ENTER to start: ")
    while enter_game != "":
        enter_game = input("welcome to the Memory Game, please try to remember the sequence of numbers,"
                           " they will be displayed only for 0.7 sec, press ENTER to start: ")
    print(secret_sequence)
    time.sleep(0.7)
    clear()
    guess_value = get_list_from_user(difficulty=difficulty)
    return is_list_equal(secret_sequence, guess_value)
import requests
import random


def get_money_interval(difficulty, ils):
    interval = (ils-(5-difficulty), ils+(5-difficulty))
    return interval


def get_guess_from_user(usd):
    guess_value = input(f"What do you think is the value of {usd}$ generated to ILS? ")
    while guess_value.isdigit() is False:
        guess_value = input(f"What do you think is the value of {usd}$ generated to ILS? ")
    return guess_value


def play(difficulty):
    currency_api = "https://v6.exchangerate-api.com/v6/5e3877145b7124101814b104/latest/USD"
    currency_rate = requests.get(currency_api).json()["conversion_rates"]["ILS"]
    usd = random.randint(1, 100)
    ils = usd*currency_rate
    min_interval, max_interval = get_money_interval(difficulty=difficulty, ils=ils)
    guess_value = float(get_guess_from_user(usd))
    if min_interval < guess_value < max_interval:
        return True
    return False

from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def score():

    with open('/Users/chenshapira/PycharmProjects/WorldOfGames/score.txt', 'r') as f:
        score = f.readlines()[0]
    # marked_up_text = score.textile(score)
    try:
        return render_template("score.html", score=score)
    except:
        return render_template("error.html")


if __name__ == '__main__':
    app.run()
